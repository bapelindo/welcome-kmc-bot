# WelcomeBot
Windows install:
1. Change the welcome channel in the config.json file.
2. Change the picture (call the picture wallpaper.jpg)
3. Insert your token.
4. Run "npm install"
(be sure that you have installed "node.js" on your pc / server.)
5. Run "node index.js"
6. Have fun!

Linux install

1.Clone the rep.
git clone https://github.com/BrainFoot/WelcomeBot (your name)

2. Change the welcome channel in the config.json file.

3. Change the picture (call the picture wallpaper.jpg)

4. Insert your token.

5. Run "npm install"
(be sure that you have installed "node.js" on your pc / server.)

6. Run "node index.js"

7. Have fun!

Screening:

nano start.sh
copypasteme:
while true; do
    node index.js
done

then use:
screen -L -S bash start.sh (your screen name)

when you dont have instaled screen use:
apt-get install screen

For more help join our [Discord](https://discord.gg/GsxjQsj)!
Tutorials:
#1 [Klick Here](https://youtu.be/TvLObBezzfw)
#2 [Klick Here](https://youtu.be/I_WJhobusBg)
